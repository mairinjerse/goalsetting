# Waypoint

A personal goal + habit dashboard: onboarding turns a goal into metrics, habits, milestones, and an identity statement, then tracks daily progress against habit-formation research (identity-based habits, if-then planning, visible progress, consistency over intensity). Includes an outreach/pipeline tracker — log contacts by category (potential client, network, referral, friend/family, colleague), mark them reached-out and booked, and watch cumulative pipeline growth on a two-line chart.

This is the working prototype pulled out of a claude.ai Artifact. It's a single self-contained `index.html` — no build step, no dependencies.

## Running it

Open `index.html` directly in a browser, or serve the folder with anything static:

```bash
npx serve .
# or
python3 -m http.server
```

## How it's built

Everything — markup, styles, and app logic — lives in `index.html`. The app renders itself from a single in-memory `state` object (goals, metrics, habits, milestones, contacts) using plain string-template functions, then re-renders on every change via `innerHTML`. There's no framework and no bundler on purpose, so it's easy to read top to bottom and easy to hand to Claude Code for the next round of changes.

## Persistence

Right now state is saved to the browser's `localStorage` (key `waypoint-state-v1`), so it survives reloads on the same device/browser but doesn't sync across devices and isn't backed up anywhere. That's the main thing worth fixing next.

The code also has leftover hooks (`ensureArtifact`, `window.claude.use("artifact")`) from when this ran inside a claude.ai Artifact, which let the page save a full snapshot of itself back to claude.ai. Those calls are harmless outside claude.ai — `window.claude` won't exist, so they silently no-op — but they're dead weight here and can be deleted once you're building this as its own product. Same for the AI "suggest for me" onboarding feature (`ensureSample`, `window.claude.use("sample")`), which needs a real LLM API call wired up (e.g. the Claude API) to work outside claude.ai — right now the "suggest" buttons will just fail quietly.

## Suggested next steps

- Swap `localStorage` for a real backend if you want your data to survive across devices — Supabase (Postgres + auth + a JS client) is a good fit for a single-user app like this and keeps the effort small.
- Add auth if this is ever going to have more than one user.
- Wire the "suggest for me" buttons to a real LLM call (Claude API) instead of the claude.ai-only `sample` capability.
- Extract the giant inline `<script>` into real modules once you're ready to add a build step — not necessary before then.

## Where this came from

Built iteratively as a claude.ai Artifact (that's why some of the code has claude.ai-specific hooks, noted above). This export is a clean, empty-state starting point — no personal data included.
